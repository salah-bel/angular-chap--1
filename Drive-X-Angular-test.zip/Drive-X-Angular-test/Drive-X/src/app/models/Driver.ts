export class Driver {

    constructor(public fullName:string,
                public pays:string,
                public coverImage:string,
                public category?:string,
                public likeIts:number = 0){}

}
